//
//  GlassTab.swift
//  demo-lib
//
//  Created by Dhruv Chhatbar on 21/07/26.
//

import Foundation
import SwiftUI

public struct GlassTab1 {
    public let systemImage: String
    public let label: String

    public init(systemImage: String, label: String) {
        self.systemImage = systemImage
        self.label = label
    }
}

// MARK: - GlassTabBar

public struct GlassTabBar: View {
    public let tabs: [GlassTab1]
    @Binding public var selectedIndex: Int

    public init(tabs: [GlassTab1], selectedIndex: Binding<Int>) {
        self.tabs = tabs
        self._selectedIndex = selectedIndex
    }

    public var body: some View {
        #if os(Android)
        ComposeView {
            GlassTabBarComposer(tabs: tabs, selectedIndex: selectedIndex)
//            TextComposer()
        }
        .frame(height: 64)
        #else

        Text(tabs.map(\.label).joined(separator: " ,"))
        .frame(height: 64)
        #endif
    }
}

#if SKIP

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.material3.Text
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy

private func materialIcon(for systemImage: String) -> ImageVector {
    switch systemImage {
    case "house.fill", "house": return Icons.Filled.Home
    case "magnifyingglass": return Icons.Filled.Search
    case "heart.fill", "heart": return Icons.Filled.Favorite
    case "person.fill", "person": return Icons.Filled.Person
    default: return Icons.Filled.Home
    }
}

struct TextComposer: ContentComposer {
    @Composable func Compose(context: ComposeContext) {
        let backdrop = rememberLayerBackdrop { drawContent() }
        Text(text: "ASDSDAD")
    }
}

struct GlassTabBarComposer : ContentComposer {
    let tabs: [GlassTab1]
    let selectedIndex: Int

    @Composable func Compose(context: ComposeContext) {
        let backdrop = rememberLayerBackdrop { drawContent() }

        BoxWithConstraints(
            modifier: Modifier.fillMaxWidth().height(64.dp),
            contentAlignment: Alignment.CenterStart
        ) {
            let density = LocalDensity.current
            let tabWidth = maxWidth / tabs.count
            let tabWidthPx = with(density) { tabWidth.toPx() }
            let isLtr = LocalLayoutDirection.current == LayoutDirection.Ltr
            let current = selectedIndex
            
            let animatedIndex = animateFloatAsState(
                targetValue: Float(current),
                animationSpec: spring(
                    dampingRatio: Spring.DampingRatioMediumBouncy,
                    stiffness: Spring.StiffnessLow
                )
            ).value
            Text(text: "ASD")
            // 1. Glass container.
            Box(
                modifier: Modifier
                    .fillMaxSize()
                    .drawBackdrop(
                        backdrop: backdrop,
                        shape: { RoundedCornerShape(32.dp) },
                        effects: {
                            vibrancy()
                            blur(Float(12.dp.toPx()))
                            lens(Float(12.dp.toPx()), Float(24.dp.toPx()))
                        },
                        onDrawSurface: {
                            drawRect(Color.White.copy(alpha: Float(0.18)))
                        }
                    )
            )
            
            // 2. Sliding glass pill.
            Box(
                modifier: Modifier
                    .graphicsLayer {
                        translationX = (isLtr) ? animatedIndex * tabWidthPx : size.width - (animatedIndex + 1) * tabWidthPx
                    }
                    .width(tabWidth)
                    .fillMaxHeight()
                    .padding(6.dp)
                    .drawBackdrop(
                        backdrop: backdrop,
                        shape: { RoundedCornerShape(26.dp) },
                        effects: {
                            vibrancy()
                            blur(Float(6.dp.toPx()))
                            lens(Float(8.dp.toPx()), Float(16.dp.toPx()))
                        },
                        onDrawSurface: {
                            drawRect(Color.White.copy(alpha: Float(0.38)))
                        }
                    )
            )
            
            Row(
                modifier: Modifier.fillMaxSize(),
                horizontalArrangement: Arrangement.SpaceEvenly,
                verticalAlignment: Alignment.CenterVertically
            ) {
//                for (index, tab) in tabs.enumerated() {
//                    let isSelected = index == current
//                    Box(
//                        modifier: Modifier
//                            .weight(Float(1.0))
//                            .fillMaxHeight()
//                            .clickable(
//                                interactionSource: remember { MutableInteractionSource() },
//                                indication: nil
//                            ) { selectedIndex = index },
//                        contentAlignment: Alignment.Center
//                    ) {
//                        Icon(
//                            imageVector: materialIcon(for: tab.systemImage),
//                            contentDescription: tab.label,
////                            tint:  (isSelected) ? Color.White : Color.White.copy(alpha: 0.5),
////                            modifier: Modifier.size(24.dp).scale( (isSelected) ? Float(1.15) : Float(1.0))
//                        )
//                    }
//                }
                
            }
        }
    }
}
#endif
