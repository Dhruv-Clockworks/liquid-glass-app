//
//  DroidDexBridge.swift
//  demo-lib
//
//  Created by Dhruv Chhatbar on 20/07/26.
//

import Foundation

#if SKIP
import android.app.Application
import android.content.Context
import com.blinkit.droiddex.DroidDex
import com.blinkit.droiddex.constants.PerformanceClass
#endif

public struct DroidDexBridge1 {
    private init() {}
    
    private var isInitialised = false
    
    public static func initialise() {
#if SKIP
        if isInitialised { return }
        if let application = ProcessInfo.processInfo.androidContext {
            DroidDex.init(application)
            isInitialised = true
        }
#endif
    }
    
    static func performanceLevel(className: String) -> String {
#if SKIP
        if let flag = toPerformanceClassFlag(className) {
            return DroidDex.getPerformanceLevel(flag).name
        } else { return "AVERAGE" }
#else
        return "AVERAGE"
#endif
    }
    
    private static func toPerformanceClassFlag(name: String) -> Int {
#if SKIP
        switch name.uppercased() {
            case "CPU": return PerformanceClass.CPU
            case "MEMORY": return PerformanceClass.MEMORY
            case "NETWORK": return PerformanceClass.NETWORK
            case "STORAGE": return PerformanceClass.STORAGE
            case "BATTERY": return PerformanceClass.BATTERY
            default: return PerformanceClass.CPU
        }
#else
        return 0
#endif
    }
}
