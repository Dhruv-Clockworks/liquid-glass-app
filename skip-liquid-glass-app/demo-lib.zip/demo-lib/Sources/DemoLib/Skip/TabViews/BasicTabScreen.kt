package demo.lib

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

@Composable
fun BasicTabScreen(
    modifier: Modifier = Modifier,
    currentDevice: String = ""
) {
    var selectedTab by rememberSaveable { mutableStateOf("Home") }

    val tabs = remember {
        listOf(
            GlassTab(Icons.Filled.Home, "Home"),
            GlassTab(Icons.Filled.Favorite, "Favorites"),
            GlassTab(Icons.Filled.Info, "Info")
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar {
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = tab.label == selectedTab,
                        onClick = { selectedTab = tab.label },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            TabPlaygroundScreen(
                modifier = Modifier.fillMaxSize(),
                currentDevice = currentDevice,
                label = selectedTab
            )
        }
    }
}