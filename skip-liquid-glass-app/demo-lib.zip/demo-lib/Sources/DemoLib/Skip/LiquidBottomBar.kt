package demo.lib

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.fastCoerceIn
import androidx.compose.ui.util.fastRoundToInt

import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy

import demo.lib.DampedDragAnimation
import demo.lib.InteractiveHighlight

import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.drop

@Composable
fun StandaloneLiquidGlassTabBar(modifier: Modifier = Modifier) {
    val backdrop = rememberLayerBackdrop {
        drawContent()
    }

    var selectedTab by rememberSaveable { mutableIntStateOf(0) }

    val tabs = remember {
        listOf(
            GlassTab(Icons.Filled.Person, "Home1"),
            GlassTab(Icons.Filled.Search, "Search"),
            GlassTab(Icons.Filled.Favorite, "Saved"),
            GlassTab(Icons.Filled.Person, "Profile")
        )
    }

    LiquidGlassTabBar(
        backdrop = backdrop,
        tabs = tabs,
        selectedIndex = selectedTab,
        onTabSelected = { selectedTab = it },
        modifier = modifier.padding(horizontal = 24.dp, vertical = 32.dp)
    )
}

data class GlassTab(val icon: ImageVector, val label: String)

/**
 * Liquid-glass bottom tab bar. The indicator pill is purely visual;
 * a separate, invisible, pill-sized overlay drawn on TOP of everything
 * else owns the actual drag/press gesture (mirrors Kyant's layering —
 * touching the highlighted tab grabs the drag layer, touching anywhere
 * else falls through to that tab's own clickable icon).
 */
@Composable
fun LiquidGlassTabBar(
    backdrop: Backdrop,
    tabs: List<GlassTab>,
    selectedIndex: Int,
    onTabSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(76.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        val density = LocalDensity.current
        val tabWidth = maxWidth / tabs.size
        val tabWidthPx = with(density) { tabWidth.toPx() }
        val isLtr = LocalLayoutDirection.current == LayoutDirection.Ltr
        val animationScope = rememberCoroutineScope()

        // The "settled" tab — drives onTabSelected + icon highlight state.
        var currentIndex by remember { mutableIntStateOf(selectedIndex) }

        val dampedDragAnimation = remember(animationScope) {
            DampedDragAnimation(
                animationScope = animationScope,
                initialValue = selectedIndex.toFloat(),
                valueRange = 0f..(tabs.size - 1).toFloat(),
                visibilityThreshold = 0.001f,
                initialScale = 1f,
                pressedScale = 1.08f,
                onDragStarted = {},
                onDragStopped = {
                    val targetIndex = targetValue.fastRoundToInt().fastCoerceIn(0, tabs.size - 1)
                    currentIndex = targetIndex
                    animateToValue(targetIndex.toFloat())
                },
                onDrag = { _, dragAmount ->
                    updateValue(
                        (targetValue + dragAmount.x / tabWidthPx * if (isLtr) 1f else -1f)
                            .fastCoerceIn(0f, (tabs.size - 1).toFloat())
                    )
                }
            )
        }

        // Sync external / programmatic changes to selectedIndex.
        LaunchedEffect(selectedIndex) {
            if (selectedIndex != currentIndex) {
                currentIndex = selectedIndex
                dampedDragAnimation.animateToValue(selectedIndex.toFloat())
            }
        }

        // Drag-driven settling (and tap selection below) notify the caller.
        LaunchedEffect(dampedDragAnimation) {
            snapshotFlow { currentIndex }
                .drop(1)
                .collectLatest { index -> onTabSelected(index) }
        }

        val interactiveHighlight = remember(animationScope) {
            InteractiveHighlight(
                animationScope = animationScope,
                position = { size, _ ->
                    Offset(
                        if (isLtr) (dampedDragAnimation.value + 0.5f) * tabWidthPx
                        else size.width - (dampedDragAnimation.value + 0.5f) * tabWidthPx,
                        size.height / 2f
                    )
                }
            )
        }

        // Shared position transform for both the visual pill and the gesture overlay.
        val pillTranslationX: androidx.compose.ui.graphics.GraphicsLayerScope.() -> Float = {
            if (isLtr) dampedDragAnimation.value * tabWidthPx
            else size.width - (dampedDragAnimation.value + 1f) * tabWidthPx
        }

        // 1. Container glass surface — carries the touch-following highlight glow.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { RoundedCornerShape(38.dp) },
                    effects = {
                        vibrancy()
                        blur(20f.dp.toPx())
                        lens(16f.dp.toPx(), 32f.dp.toPx(), true)
                    },
                    onDrawSurface = {
                        drawRect(Color.White.copy(alpha = 0.18f))
                    }
                )
                .then(interactiveHighlight.modifier)
        )

        // 2. Sliding liquid pill — purely visual, position/scale read from DampedDragAnimation.
        Box(
            modifier = Modifier
                .graphicsLayer {
                    translationX = pillTranslationX()
                    scaleX = dampedDragAnimation.scaleX
                    scaleY = dampedDragAnimation.scaleY
                }
                .width(tabWidth)
                .fillMaxHeight()
                .padding(6.dp)
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { RoundedCornerShape(30.dp) },
                    effects = {
                        vibrancy()
                        blur(10f.dp.toPx())
                        lens(10f.dp.toPx(), 22f.dp.toPx(), true)
                    },
                    onDrawSurface = {
                        drawRect(Color.White.copy(alpha = 0.38f))
                    }
                )
        )

        // 3. Foreground icon row — tapping still jumps straight to a tab.
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEachIndexed { index, tab ->
                val isSelected = index == currentIndex

                val iconScale by animateFloatAsState(
                    targetValue = if (isSelected) 1.25f else 1.0f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow
                    ),
                    label = "IconScale"
                )

                val iconColor by animateColorAsState(
                    targetValue = if (isSelected) Color.White else Color.White.copy(alpha = 0.5f),
                    animationSpec = tween(durationMillis = 250),
                    label = "IconColor"
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            currentIndex = index
                            dampedDragAnimation.animateToValue(index.toFloat())
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = tab.icon,
                        contentDescription = tab.label,
                        tint = iconColor,
                        modifier = Modifier
                            .size(26.dp)
                            .scale(iconScale)
                    )
                }
            }
        }

        // 4. Invisible gesture-only overlay, topmost, same size/position as the pill.
        //    This is what actually owns the drag — touching the highlighted tab
        //    grabs it (since it's on top there); touching elsewhere falls through
        //    to the clickable icons in the Row above, since this overlay is only
        //    tabWidth wide.
        Box(
            modifier = Modifier
                .graphicsLayer {
                    translationX = pillTranslationX()
                }
                .then(interactiveHighlight.gestureModifier)
                .then(dampedDragAnimation.modifier)
                .width(tabWidth)
                .fillMaxHeight()
        )
    }
}