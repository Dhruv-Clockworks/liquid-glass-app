//
//  TabView.swift
//  demo-lib
//
//  Created by Dhruv Chhatbar on 17/07/26.
//

import Foundation
import SwiftUI


#if SKIP
struct LiquidGlassTabScreenComposer: ContentComposer {
    let currentDevice: String
    @Composable func Compose(context: ComposeContext) {
        LiquidGlassTabScreen(modifier: context.modifier, currentDevice: currentDevice)
    }
}

struct MediumGlassTabScreenComposer: ContentComposer {
    let currentDevice: String
    @Composable func Compose(context: ComposeContext) {
        MediumGlassTabScreen(modifier: context.modifier, currentDevice: currentDevice)
    }
}

struct BasicTabScreenComposer: ContentComposer {
    let currentDevice: String
    @Composable func Compose(context: ComposeContext) {
        BasicTabScreen(modifier: context.modifier, currentDevice: currentDevice)
    }
}
#endif
